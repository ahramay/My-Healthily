import React, { useRef } from "react";
import styles from "./JobManager.module.css";

interface props {
  title: string;
  setTitle: React.Dispatch<React.SetStateAction<string>>;
  handleAdd: (e: React.FormEvent) => void;
}

const InputField: React.FC<props> = ({ handleAdd }) => {
  const inputRef = useRef<HTMLInputElement>(null);

  return (
    <form
      className={styles.input}
      onSubmit={(e) => {
        handleAdd(e);
        inputRef.current?.blur();
      }}
    ></form>
  );
};

export default InputField;
